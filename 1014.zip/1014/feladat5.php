<?php> 
$tomb = array();
$tomb[] = 2; 
$tomb[] = 55;
$tomb[2]
?>