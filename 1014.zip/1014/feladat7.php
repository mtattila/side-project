<?php
$c=2 * $a / $b